package com.example.freon.b25lstdt;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.zip.Inflater;

public class MyAdapter extends BaseAdapter {
    String[] data = new String[0];
    LayoutInflater inflater;

    public void setData(String[] newData){
        data = newData;
    }

    @Override
    public int getCount() {
        if(data != null)
            return data.length;
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return data[position];
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        MyHolder myHolder;
        if(inflater == null){
            inflater = (LayoutInflater)parent.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        View itemView = inflater.inflate(R.layout.item, parent, false);
        TextView data1 = (TextView) itemView.findViewById(R.id.data1);
        TextView data2 = (TextView) itemView.findViewById(R.id.data2);
        TextView data3 = (TextView) itemView.findViewById(R.id.data3);
        myHolder = new MyHolder(data1 , data2 , data3);
        String item = (String)getItem(position);
        myHolder.data1.setText("" + position);
        myHolder.data2.setText(item);
        myHolder.data3.setText(" ");
        itemView.setTag(myHolder);
        return itemView;
    }

    public static final class MyHolder{
        TextView data1;
        TextView data2;
        TextView data3;
        public MyHolder(TextView data1, TextView data2, TextView data3 ){
            this.data1 = data1;
            this.data2 = data2;
            this.data3 = data3;
        }


    }
}
